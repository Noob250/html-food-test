$(function (){
    $(".info-content-item-img").hover(function (){
        var baseLeft = $(this).position().left - 80;
        var baseTop = $(this).offset().top - 830;
        img = $(this).css("background-image")
        $(".img-box").css({"opacity": '1', "left": baseLeft + "px", "top": baseTop + "px", "background-image":img})
    }, function (){
        $(".img-box").css("opacity", '0')
    })
})