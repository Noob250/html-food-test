$(function (){
   $(".top-bar a").each(function (event){
       $(this).hover(function (){
           var baseLeft = $(this).offset().left;
           $(".selector").css({"transition":"all 0.4s", "left": baseLeft+"px",
               "background-color": "#ff6a00", "opacity": "1"},);
       }, function (){
           $(".selector").css({"opacity": "0"})
       })
    })
    $("#autograph").click(function (){
        window.location.href = "../template/index.html"
    })
    var barArray = $(".top-bar a")
    $(barArray[0]).attr("href","theme.html")
    $("#user-food").click(function (){
        window.location.href = "../template/food_index.html"
    })
    $(".about dt").click(function (){
        window.location.href = "../template/about-us.html"
    })
})