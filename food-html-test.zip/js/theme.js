$(function (){
    var huaxue = new Array(4);
    $(".info-intro-bar").each(function (){
        $($(this).children("div")[0]).css("border-bottom","3px solid #ff9d00")
    })
    var clearBorder = function(parent){
         $(parent).parent("div").find(".info-intro-bar-name").each(function (){
            $(this).css("border-bottom","none");
        })
    };
   $(".info-intro-bar-name").click(function (){
       clearBorder(this);
        $(this).css("border-bottom","3px solid #ff9d00")
   });
    $(".info-intro-content-item-detail").hover(function (){
        $(this).find(".info-intro-content-item-detail-content").css("height", "230px")
    }, function (){
        $(this).find(".info-intro-content-item-detail-content").css("height", "60px")
    })

    $.getJSON("../data/huwai.json", function (data){
         $(".info-intro-bar-name").click(function (){
             var index = $(this).attr("data-index")
             var box1 = $("#huwai-item1")
             var box2 = $("#huwai-item2")
             var box3 = $("#huwai-item3")
             var box4 = $("#huwai-item4")
             var boxArray = [box1, box2, box3, box4];
             for(var i = 0; i < data[index].length; i++) {

                 var title = data[index][i].title;
                 var content = data[index][i].content;
                 var img = "../images/" + data[index][i].img + ".jpg";
                 $(boxArray[i]).find(".info-intro-content-item-detail-title").html(title)
                 $(boxArray[i]).find(".info-intro-content-item-detail-content").html(content)
                 $(boxArray[i]).css("background-image","url("+img+")")
             }
         })
    })
})