$(function (){

    var imgBox = "<div class="+"img-item-box"+"><div class="+"item-img"+"></div><div class="+"item-title"+"><span></span></div></div>"
    $(".all-img-box").each(function (){
        for (var i = 0; i < 15; i++){
            $(this).append(imgBox)
        }
    })
    $(".img-item-box").hover(function (){
        $(this).find("span").css("color","#ff6a00")
    }, function (){
        $(this).find("span").css("color","black")
    })

    $.getJSON("../data/jinan.json", function (data){
     var pageNumber = data["img"].length / 15
     var index= 1 // 页码
     $(".pagination").each(function (){
         for (var i = 0; i < pageNumber+2; i++){
            var pageBox = "<div class="+"page-number"+" dataIndex="+i+"></div>"
            $(this).append(pageBox)
        }
     });
     pageBoxArray = $(".page-number")
    var refreshImg = function (data, i){
         $(".item-img").each(function (){
             title = data["img"][i].title
             img = data["img"][i].imgUrl
             i++
             $(this).css("background-image","url("+img+")")
             $(this).parent().find(".item-title span").html(title)
         })
     }
     var refreshPage = function (elem){
         for (var j = 1; j < pageBoxArray.length-1; j++){
             $(pageBoxArray[j]).css("background-color", "#fff4f5")
         }
         $(elem).css("background-color", "#ff6a00")
     }
     $(pageBoxArray[0]).html("上一页")
     $(pageBoxArray[pageBoxArray.length-1]).html("下一页")
     $(".all-page").html("第"+index+"/"+(pageBoxArray.length-2)+"页")
     refreshImg(data, 0)
     currentI = 0
     for (var j = 1; j < pageBoxArray.length-1; j++){
         $(pageBoxArray[j]).html(j)
         $(pageBoxArray[j]).click(function (){
             //修改图片
             currentI = $(this).attr("dataindex") - 1
             refreshImg(data, currentI*15)
             // 修改颜色
             refreshPage(this)
             $(".all-page").html("第"+(currentI+1)+"/"+(pageBoxArray.length-2)+"页")
         })
     }
     $(pageBoxArray[0]).click(function (){
         // console.log(currentI)
         if (currentI > 0) {
             currentI--
             // console.log(currentI)
             refreshPage(pageBoxArray[currentI+1])
             refreshImg(data, currentI*15)
             $(".all-page").html("第"+(currentI+1)+"/"+(pageBoxArray.length-2)+"页")
         }
     })
        $(pageBoxArray[pageBoxArray.length-1]).click(function (){

         if (currentI < pageBoxArray.length - 3) {
             currentI++
             // console.log(currentI)
             refreshPage(pageBoxArray[currentI+1])
             refreshImg(data, currentI*15)
             $(".all-page").html("第"+(currentI+1)+"/"+(pageBoxArray.length-2)+"页")
         }
     })
















    })
})