$(function (){
    var index = 0;
    var items = $(".item-img")
    var preBtn = $("#pre-btn");
    var nextBtn = $("#next-btn");
    var points = $(".point");
    var timer = 0;

    points[0].className = "point active";
    items[0].className = "item-img active";

    var clearActive = function (){
        items.each(function (){
            $(this).removeClass("item-img active").addClass("item-img")
        })
        points.each(function (){
            $(this).removeClass("point active").addClass("point")
        })
    }
    var goIndex = function (){
        clearActive();
        if (index >= items.length){
            index = 0;
        } else if(index < 0){
            index = items.length-1;
        }
        items[index].className = "item-img active";
        points[index].className = "point active";
    }

    preBtn.click(function (){
        index--;
        goIndex();
        timer = 0;
    });
    nextBtn.click(function (){
        index++;
        goIndex();
        timer = 0;
    });

    setInterval(function (){
        timer++;
        if(timer === 30){
            index++;
            goIndex();
            timer = 0;
        }
    }, 100)
    points.each(function (){
        $(this).click(function (){
            index = this.getAttribute("data-index");
            goIndex();
            timer = 0;
        })
    })

    var clearTag = function (){
        $(".travels-tag").each(function (){
            $(this).css({"border-bottom": "none"})
        });
    }
    $(".travels-tag:first").css({"border-bottom": "3px solid #ff6a00"})
    $(".travels-tag").each(function (){
       $(this).click(function (){
           clearTag()
           $(this).css({"border-bottom": "3px solid #ff6a00"})
       }) ;
    });
    $(".preview-img").each(function (){
        $(this).mouseover(function (){
            $(this).next().css({"opacity":"1", "top":"-60px"})
        });
        $(this).mouseleave(function (){
            $(this).next().css({"opacity":"0", "top":"0"})
        });
    });

    $(".hot").click(function (){
        hot = $(this).html()
        $("#search-input").val(hot)
    })

    $("#travels1").click(function (){
        window.location.href = "../template/travel1.html"
    })

    hotSearchArray = [
        {
            "key": "济南",
            "value": "../template/jinan.html"
        }
    ]

    $("#search-btn").click(function (){
        hotsearch = $("#search-input").val()
        for(var i = 0; i < hotSearchArray.length; i++){
            if(hotsearch === hotSearchArray[i].key){
                window.location.href = hotSearchArray[i].value
            }
        }
    })
    $("#hot-food").click(function (){
        window.location.href = "../template/food_index.html"
    })

});