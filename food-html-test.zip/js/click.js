// 获取汉堡按钮
const burger = document.querySelector(".burger");

const Menu = document.querySelector(".menu");

const MenuItems = document.querySelectorAll(".menu li");

burger.addEventListener("click", () => {
    burger.classList.toggle("active");
    Menu.classList.toggle("open");
    //对每一导航栏元素添加具体应如何应用 动画的效果方式
    MenuItems.forEach((item, index) => {
        if(item.style.animation) {
            item.style.animation = "";//可能重复应用动画效果 所以如果存在动画效果 那么就先取消
        }
        else {
            item.style.animation = `0.3s ease-in slideIn forwards 
             ${index * 0.1 + 0.3}s`
            //相当于每个导航栏中的元素 比上一个元素延迟0.1s变化 但是一个元素的动画时间是0.3s所以再加上0.3s
        }
    });

    // console.log(123);//可以用log来测试 点击是否被获取到
});
